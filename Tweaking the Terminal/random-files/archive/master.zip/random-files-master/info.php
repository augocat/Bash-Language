<?php

// PHP File to show information about php and your system

phpinfo();
